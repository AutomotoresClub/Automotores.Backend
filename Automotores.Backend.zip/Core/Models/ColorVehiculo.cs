namespace Automotores.Backend.Core.Models
{
    public class ColorVehiculo
    {
        public int Id { get; set; }

        public string Nombre { get; set; }
    }
}