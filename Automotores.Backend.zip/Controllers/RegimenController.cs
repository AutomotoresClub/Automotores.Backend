namespace Automotores.Backend.Controllers
{
    public class RegimenController
    {
        
    }
}