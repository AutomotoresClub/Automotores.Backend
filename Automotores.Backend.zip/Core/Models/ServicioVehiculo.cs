namespace Automotores.Backend.Core.Models
{
    public class ServicioVehiculo
    {
        public int Id { get; set; }

        public string Nombre { get; set; }
    }
}