namespace Automotores.Backend.Extensions
{
    public class IMailObject
    {
        
    }
}