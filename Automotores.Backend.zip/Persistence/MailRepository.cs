using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Amazon;
using Amazon.SimpleEmail;
using Amazon.SimpleEmail.Model;
using Automotores.Backend.Core;

namespace Automotores.Backend.Persistence
{
    public class MailRepository : IMailRepository
    {
    }
}