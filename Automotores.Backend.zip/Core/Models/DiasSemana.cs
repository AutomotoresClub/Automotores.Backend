namespace Automotores.Backend.Core.Models
{
    public class DiasSemana
    {
        public int Id { get; set; }

        public string Nombre { get; set; }
    }
}