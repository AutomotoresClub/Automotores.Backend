namespace Automotores.Backend.Core.Models
{
    public class SentryOptions
    {
        public string Dsn { get; set; }
    }
}