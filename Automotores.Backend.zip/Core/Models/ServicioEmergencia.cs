namespace Automotores.Backend.Core.Models
{
    public class ServicioEmergencia
    {
        public int Id { get; set; } 

        public string Nombre { get; set; }
    }
}