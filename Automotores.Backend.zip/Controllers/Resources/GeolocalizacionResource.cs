namespace Automotores.Backend.Controllers.Resources
{
    public class GeolocalizacionResource
    {
        public float Latitud { get; set; }

        public float Longitud { get; set; }
    }
}